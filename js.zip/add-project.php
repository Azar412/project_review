<?php include 'header.php';?>
<?php 
error_reporting(0);
$con =mysqli_connect("localhost","root","","project");
if(isset($_POST['save_data'])){

    $pname =$_POST['pname']; 

    $query_exit=mysqli_query($con,"select * from add_project where project_name='$pname' ");

    if(mysqli_num_rows($query_exit)>0){
        $mail_message= "Project  already exists";
    }
    else{
        $query = "insert into add_project (project_name) values
        ('$pname')";
        $result =mysqli_query($con,$query);

    

    

     if(!$result){
         $error ="Not Registered";
     }
     else{
         $message="Registered Successfully";
         header('location:adminhome.php');
     }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daily Task</title>
    <link href="css/custom.css" rel="stylesheet">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
<div class="container">
    <div class="row mt-5">
        <div class="col d-flex justify-content-center">
            <h1>Register Here</h1>
        </div>
    </div>

<div class="form-design">
<form action="" method="post" enctype="multipart/form-data">
<div class="row">
  
<div class="col-lg-6">
<label>Project Name</label>
<input type="text" name="pname" class="form-control " placeholder="Enter the Project name">
<?php 
                                          if(mysqli_num_rows($query_exit)>0){
                                                ?>
                                                <div style="color:red;">
                                                <?php echo $mail_message;
                                                ?>
                                                </div>

                                                <?php
                                            }
                                            ?>
</div>

<div class="col-lg-12 mt-5 text-center">
<input class="btn btn-primary"  name="save_data" type="submit">
</div>

</div>
</form>
</div>
</div>
</body>
</html>