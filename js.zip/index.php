<?php include 'header.php' ?>



<div class="ltn__slider-area ltn__slider-3  section-bg-1">
    <div class="ltn__slide-one-active slick-slide-arrow-1 slick-slide-dots-1 slick-initialized slick-slider slick-dotted"
        role="toolbar">
        <!-- ltn__slide-item -->
        <!--  -->

        <div aria-live="polite" class="slick-list draggable">
            <div class="slick-track" style="opacity: 1; width: 3040px;" role="listbox">
                <div class="ltn__slide-item ltn__slide-item-2 ltn__slide-item-3-normal ltn__slide-item-3 slick-slide slick-current slick-active"
                    style="width: 1520px; position: relative; left: 0px; top: 0px; z-index: 999; opacity: 1;"
                    tabindex="-1" role="option" aria-describedby="slick-slide00" data-slick-index="0"
                    aria-hidden="false">
                    <div class="ltn__slide-item-inner">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-3">
                                <a href="login.php" class="theme-btn-1 btn btn-effect-1" tabindex="0">Login</a>
                                </div>
                                <div class="col-lg-3">
                                <a href="view-status.php" class="theme-btn-1 btn btn-effect-1" tabindex="0">View Individual Status</a>
                                </div>
                                
                                <div class="col-lg-3 ">
                                <a href="view-all-project.php" class="theme-btn-1 btn btn-effect-1" tabindex="0">View All Status</a>
                                </div>
                                
                                <div class="col-lg-3">
                                <a href="admin.php" class="theme-btn-1 btn btn-effect-1" tabindex="0">Admin</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div>
</div>


<?php include 'footer.php';?>